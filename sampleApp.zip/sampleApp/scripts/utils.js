function toggleLoading(bool) {
    if (bool == 1){

        $('html').prepend("<div id='block' class='transparent'    style=' zoom: 1; filter: alpha(opacity=50);  opacity: 0.5; margin-top:0px;float: left; height: 100%; width: 100%; position: absolute; background-color: #c3bfd4;z-index:1'>");
        $('html').prepend("<img id='loading' src='images/loading.gif' style='margin-left: 45%;margin-top: 20%;position: absolute; float:left;z-index:2'/>");

    }

    if (bool == 0) {

        $("#block").remove();
        $("#loading").remove();

    }
}